<?php
$data=array (
  'records' => 
  array (
    array (
      'fields' => 
      array (
        'Full Name' => $_POST['fullname'],
        'Email' => $_POST['email'],
        'Mobile' => $_POST['phone'],
		'Subject' => $_POST['subject'],
		 'Source ' => 
			array (
			  0 => 'Greenpwr.eu Web',
			),
		  'language' => $_POST['language'],
		
      ),
    ),
  ),
);
$je=json_encode($data);
$curl = curl_init();

curl_setopt_array($curl, array(
  CURLOPT_URL => 'https://api.airtable.com/v0/appx70ZIVSjyZjXvM/Table%201',
  CURLOPT_RETURNTRANSFER => true,
  CURLOPT_ENCODING => '',
  CURLOPT_MAXREDIRS => 10,
  CURLOPT_TIMEOUT => 0,
  CURLOPT_FOLLOWLOCATION => true,
  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
  CURLOPT_CUSTOMREQUEST => 'POST',
  CURLOPT_POSTFIELDS =>$je,
  CURLOPT_HTTPHEADER => array(
    'Authorization: Bearer keypH08O8fFhI3tiR',
    'Content-Type: application/json',
    'Cookie: brw=brwfAGlgsc30J9vk2'
  ),
));

$response = curl_exec($curl);

curl_close($curl);
echo $response;
?>