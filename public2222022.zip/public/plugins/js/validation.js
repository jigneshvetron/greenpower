
$(document).ready(function () {
  $("#form").validate({
    rules: {
      email: {
        required: true,
        email: true,
      },
      fullname: {
        required: true,
      },
      phone: {
        required: true,
        maxlength: 12,
        digits: true,
      },
      message: {
        required: true,
      },
    },
    messages: {
      email: {
        required: "Please enter Email Address.",
        email: "Please enter a valid Email Address.",
      },
      fullname: {
        required: "Please enter Fullname.",
      },
      phone: {
        required: "Please enter phone Number.",
        rangelength: "Contact should be 12 digit number.",
      },
      message: {
        required: "Please enter Message.",
      },
    },
    submitHandler: function (form) {
      $(".ajax-loader").show();
      $(".success_msg").show();
      form.submit();
    },
  });
});

