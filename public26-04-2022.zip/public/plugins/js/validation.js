$(document).ready(function () {
  var langMsg = {
    en: {
      emailreq: "Please enter Email Address.",
      email: "Please enter a valid Email Address.",
      fullname: "Please enter Fullname.",
      phonereq: "Please enter phone Number.",
      phonemax: "Contact should be 12 digit number.",
      message: "Please enter Message.",
    },
    es: {
      emailreq: "Ingrese la dirección de correo electrónico.",
      email: "Por favor, introduce una dirección de correo electrónico válida.",
      fullname: "Por favor ingrese Nombre completo.",
      phonereq: "Por favor, introduzca el número de teléfono.",
      phonemax: "El contacto debe ser un número de 12 dígitos.",
      message: "Por favor ingrese Mensaje.",
    },
    ge: {
      emailreq: "Bitte E-Mail-Adresse eingeben.",
      email: "Bitte geben Sie eine gültige E-Mail-Adresse ein.",
      fullname: "Bitte geben Sie den vollständigen Namen ein.",
      phonereq: "Bitte Telefonnummer eingeben.",
      phonemax: "Der Kontakt sollte eine 12-stellige Nummer sein.",
      message: "Bitte Nachricht eingeben.",
    },
    du: {
      emailreq: "Voer e-mailadres in.",
      email: "Vul een geldig e-mailadres in.",
      fullname: "Vul a.u.b. Volledige naam in.",
      phonereq: "Voer het telefoonnummer in.",
      phonemax: "Contactpersoon moet een 12-cijferig nummer zijn.",
      message: "Voer a.u.b. Bericht in.",
    },
    fr: {
      emailreq: "Veuillez saisir l'adresse e-mail.",
      email: "S'il vous plaît, mettez une adresse email valide.",
      fullname: "Veuillez entrer le nom complet.",
      phonereq: "Veuillez entrer le numéro de téléphone.",
      phonemax: "Le contact doit être un numéro à 12 chiffres.",
      message: "Veuillez saisir un message.",
    },
  };
  var languagemulti = $("#current-lang").val();
  
  // var emailreq = langMsg.languagemulti.emailreq;
  // var email = langMsg.languagemulti.email;
  // var fullname = langMsg.languagemulti.fullname;
  // var phonereq = langMsg.languagemulti.phonereq;
  // var phonemax = langMsg.languagemulti.phonemax;
  // var message = langMsg.languagemulti.message;

  $("#form").validate({
    rules: {
      email: {
        required: true,
        email: true,
      },
      fullname: {
        required: true,
      },
      phone: {
        required: true,
        maxlength: 12,
        digits: true,
      },
      message: {
        required: true,
      },
    },
    messages: {
      email: {
        required: langMsg.en.emailreq,
        email: langMsg.en.email,
      },
      fullname: {
        required: langMsg.en.fullname,
      },
      phone: {
        required: langMsg.en.phonereq,
        rangelength: langMsg.en.phonemax,
      },
      message: {
        required: langMsg.en.message,
      },
    },
    submitHandler: function (form) {
      $(".ajax-loader").show();
      //$(".success_msg").show();
      // console.log(form);
      form.submit();
    },
  });
});
